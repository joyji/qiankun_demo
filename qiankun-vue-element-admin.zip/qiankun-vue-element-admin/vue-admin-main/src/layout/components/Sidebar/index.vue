<!--
 * @Description: 
 * @Author: jiying079
 * @Date: 2022-03-14 16:36:48
 * @LastEditTime: 2022-03-15 22:44:25
-->
<template>
  <div :class="{'has-logo':showLogo}">
    <logo v-if="showLogo" :collapse="isCollapse" />
    <el-scrollbar wrap-class="scrollbar-wrapper">
      <el-menu
        :default-active="activeMenu"
        :collapse="isCollapse"
        :background-color="variables.menuBg"
        :text-color="variables.menuText"
        :unique-opened="false"
        :active-text-color="variables.menuActiveText"
        :collapse-transition="false"
        mode="vertical"
      >
        <sidebar-item v-for="route in routes" :key="route.path" :item="route" :base-path="route.path" />
      </el-menu>
    </el-scrollbar>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Logo from './Logo'
import SidebarItem from './SidebarItem'
import variables from '@/styles/variables.scss'

export default {
  components: { SidebarItem, Logo },
  computed: {
    ...mapGetters([
      'sidebar'
    ]),
    routes() {
      const routes = this.$router.options.routes;
      console.log(routes);
      return routes.concat([
        {
          path: '/pages/index/index',
          meta: { title: 'UNI-子应用的 pages', icon: 'dashboard' }
        },
        // {
        //   path: '/app-vue-hash/test/index',
        //   meta: { title: 'Vue-子应用的 home', icon: 'dashboard' }
        // },
        // {
        //   path: '/app-vue-hash/about/index',
        //   meta: { title: 'Vue-子应用的 about', icon: 'dashboard' }
        // },
        {
          path: '/layout/vue-admin-child/dashboard',
          meta: { title: '子应用的 dashboard', icon: 'dashboard' }
        },
        {
          path: '',
          meta: { title: '子应用', icon: 'form' },
          children: [
            {
              path: '/layout/vue-admin-child/form/index',
              meta: { title: '子应用的 form', icon: 'form' }
            },
            {
              path: '/layout/vue-admin-child/example/table',
              meta: { title: '子应用的 table', icon: 'table' }
            }
          ]
        }
      ]);
    },
    activeMenu() {
      const route = this.$route
      const { meta, path } = route
      // if set path, the sidebar will highlight the path you set
      if (meta.activeMenu) {
        return meta.activeMenu
      }
      return path
    },
    showLogo() {
      return this.$store.state.settings.sidebarLogo
    },
    variables() {
      return variables
    },
    isCollapse() {
      return !this.sidebar.opened
    }
  }
}
</script>
